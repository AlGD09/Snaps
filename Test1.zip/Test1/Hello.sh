#!/bin/bash
echo "Hello RCU, mein erstes Testprogramm läuft!"

